
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';

// Dummy Data
const doctorCred = {'username': 'doctor', 'password': '10'};
const patientCred = {'username': 'patient', 'password': '10'};
const registrarCred = {'username': 'mamdoh', 'password': '10'};

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();

  runApp(
    EasyLocalization(
      supportedLocales: [Locale('en'), Locale('ar')],
      path: 'assets/translations',
      fallbackLocale: Locale('en'),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Patient Manager',
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  void _login() {
    String u = _usernameController.text.trim();
    String p = _passwordController.text.trim();

    if (u == doctorCred['username'] && p == doctorCred['password']) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => DoctorHome()));
    } else if (u == patientCred['username'] && p == patientCred['password']) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => PatientHome()));
    } else if (u == registrarCred['username'] && p == registrarCred['password']) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => RegistrarHome()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Invalid credentials")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('login'.tr()),
        actions: [
          IconButton(
            icon: Icon(Icons.language),
            onPressed: () {
              context.setLocale(context.locale.languageCode == 'en' ? Locale('ar') : Locale('en'));
            },
          )
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _usernameController, decoration: InputDecoration(labelText: 'Username')),
            TextField(controller: _passwordController, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
            SizedBox(height: 20),
            ElevatedButton(onPressed: _login, child: Text('login'.tr()))
          ],
        ),
      ),
    );
  }
}

class DoctorHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Doctor Dashboard")),
      body: Center(child: Text("Welcome Doctor - View Patients and Add Reports")),
    );
  }
}

class PatientHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Patient Dashboard")),
      body: Center(child: Text("Welcome Patient - Search by Name & View Reports")),
    );
  }
}

class RegistrarHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Registrar Dashboard")),
      body: Center(child: Text("Welcome Registrar - Add Patients, Manage Payments")),
    );
  }
}
